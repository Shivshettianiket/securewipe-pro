"""
SecureWipe Pro - Certificate Generator
Generates tamper-proof PDF + JSON wipe certificates with RSA digital signatures
"""
import os
import json
import hashlib
import uuid
import base64
import qrcode
import platform
from datetime import datetime
from io import BytesIO
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.backends import default_backend
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable, Image as RLImage
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.graphics.shapes import Drawing, Rect
from reportlab.graphics import renderPDF

CERT_DIR = os.path.join(os.path.dirname(__file__), "certs")
KEY_FILE  = os.path.join(CERT_DIR, "private_key.pem")
PUB_FILE  = os.path.join(CERT_DIR, "public_key.pem")

os.makedirs(CERT_DIR, exist_ok=True)


# ── KEY MANAGEMENT ────────────────────────────────────────────────────────────

def _get_or_create_keys():
    if os.path.exists(KEY_FILE) and os.path.exists(PUB_FILE):
        with open(KEY_FILE, "rb") as f:
            private_key = serialization.load_pem_private_key(f.read(), password=None, backend=default_backend())
        with open(PUB_FILE, "rb") as f:
            public_key = serialization.load_pem_public_key(f.read(), backend=default_backend())
        return private_key, public_key

    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048, backend=default_backend())
    public_key  = private_key.public_key()

    with open(KEY_FILE, "wb") as f:
        f.write(private_key.private_bytes(serialization.Encoding.PEM,
                serialization.PrivateFormat.TraditionalOpenSSL, serialization.NoEncryption()))
    with open(PUB_FILE, "wb") as f:
        f.write(public_key.public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo))

    return private_key, public_key


def _sign_data(data: bytes) -> str:
    private_key, _ = _get_or_create_keys()
    sig = private_key.sign(data, padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH), hashes.SHA256())
    return base64.b64encode(sig).decode()


def _get_public_key_pem() -> str:
    _, public_key = _get_or_create_keys()
    return public_key.public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo).decode()


# ── MAIN CERTIFICATE GENERATOR ────────────────────────────────────────────────

def generate_certificate(wipe_log: dict, device_info: dict) -> dict:
    cert_id  = str(uuid.uuid4()).upper()
    issued   = datetime.utcnow()

    cert_data = {
        "certificate_id":    cert_id,
        "issued_at":         issued.isoformat() + "Z",
        "issued_by":         "SecureWipe Pro v1.0 — TechnoGreen / BMIT Solapur",
        "standard":          wipe_log.get("standard", "NIST SP 800-88"),
        "wipe_method":       wipe_log.get("method_label", "Multi-Pass Overwrite"),
        "device": {
            "label":         device_info.get("label", "Test Drive"),
            "type":          device_info.get("drive_type", "Storage Device"),
            "size_mb":       wipe_log.get("size_mb", 0),
            "filesystem":    device_info.get("fstype", "N/A"),
        },
        "wipe_result": {
            "status":              wipe_log.get("verification", "PASSED"),
            "total_passes":        wipe_log.get("passes", 1),
            "entropy_score":       wipe_log.get("entropy_score", 0),
            "data_recovery_risk":  wipe_log.get("data_recovery_risk", "ZERO"),
            "pass_hashes":         wipe_log.get("pass_hashes", []),
            "start_time":          wipe_log.get("start_time", ""),
            "end_time":            wipe_log.get("end_time", ""),
        },
        "system": {
            "os":       platform.system() + " " + platform.release(),
            "hostname": platform.node(),
        },
    }

    # Hash + sign
    cert_bytes = json.dumps(cert_data, sort_keys=True).encode()
    cert_data["sha256_hash"] = hashlib.sha256(cert_bytes).hexdigest()
    cert_data["digital_signature"] = _sign_data(cert_bytes)
    cert_data["public_key_pem"]    = _get_public_key_pem()

    # Save JSON
    json_path = os.path.join(CERT_DIR, f"cert_{cert_id[:8]}.json")
    with open(json_path, "w") as f:
        json.dump(cert_data, f, indent=2)

    # QR code
    verify_url = f"SECUREWIPE://VERIFY/{cert_id}/{cert_data['sha256_hash'][:16]}"
    qr_path    = os.path.join(CERT_DIR, f"qr_{cert_id[:8]}.png")
    qr = qrcode.QRCode(version=2, box_size=6, border=2)
    qr.add_data(verify_url)
    qr.make(fit=True)
    qr_img = qr.make_image(fill_color="#00C2CB", back_color="white")
    qr_img.save(qr_path)

    # PDF
    pdf_path = os.path.join(CERT_DIR, f"cert_{cert_id[:8]}.pdf")
    _generate_pdf(cert_data, pdf_path, qr_path)

    return {
        "cert_id":   cert_id,
        "json_path": json_path,
        "pdf_path":  pdf_path,
        "qr_path":   qr_path,
        "cert_data": cert_data,
    }


# ── PDF BUILDER ───────────────────────────────────────────────────────────────

def _generate_pdf(cert: dict, out_path: str, qr_path: str):
    doc = SimpleDocTemplate(out_path, pagesize=A4,
                            leftMargin=18*mm, rightMargin=18*mm,
                            topMargin=15*mm, bottomMargin=15*mm)

    # Colors
    NAVY  = colors.HexColor("#0A0F1E")
    CYAN  = colors.HexColor("#00C2CB")
    MID   = colors.HexColor("#1E3A5F")
    LIGHT = colors.HexColor("#E2E8F0")
    GREEN = colors.HexColor("#22C55E")
    MUTED = colors.HexColor("#94A3B8")
    WHITE = colors.white

    W = A4[0] - 36*mm  # usable width

    styles = {
        "title":    ParagraphStyle("title",    fontName="Helvetica-Bold",   fontSize=22, textColor=WHITE,   spaceAfter=2,  leading=26),
        "subtitle": ParagraphStyle("subtitle", fontName="Helvetica",        fontSize=10, textColor=CYAN,    spaceAfter=6),
        "h2":       ParagraphStyle("h2",       fontName="Helvetica-Bold",   fontSize=12, textColor=CYAN,    spaceAfter=4,  spaceBefore=8),
        "body":     ParagraphStyle("body",     fontName="Helvetica",        fontSize=9,  textColor=LIGHT,   spaceAfter=3,  leading=14),
        "mono":     ParagraphStyle("mono",     fontName="Courier",          fontSize=7,  textColor=MUTED,   spaceAfter=2,  leading=10, wordWrap="CJK"),
        "badge":    ParagraphStyle("badge",    fontName="Helvetica-Bold",   fontSize=14, textColor=GREEN,   spaceAfter=4,  alignment=1),
        "center":   ParagraphStyle("center",   fontName="Helvetica",        fontSize=8,  textColor=MUTED,   alignment=1),
    }

    story = []

    # ── HEADER BANNER ────────────────────────────────────────────────────────
    header_data = [[
        Paragraph("🔐 SecureWipe Pro", styles["title"]),
        Paragraph("WIPE CERTIFICATE", styles["title"]),
    ]]
    header_table = Table(header_data, colWidths=[W*0.55, W*0.45])
    header_table.setStyle(TableStyle([
        ("BACKGROUND",  (0,0), (-1,-1), NAVY),
        ("TOPPADDING",  (0,0), (-1,-1), 10),
        ("BOTTOMPADDING",(0,0),(-1,-1), 10),
        ("LEFTPADDING", (0,0), (-1,-1), 12),
        ("RIGHTPADDING",(0,0), (-1,-1), 12),
        ("ALIGN",       (1,0), (1,0),   "RIGHT"),
        ("LINEBELOW",   (0,0), (-1,-1), 2, CYAN),
    ]))
    story.append(header_table)
    story.append(Spacer(1, 4*mm))

    # ── STATUS BADGE ─────────────────────────────────────────────────────────
    status = cert["wipe_result"]["status"]
    badge_color = GREEN if status == "PASSED" else colors.HexColor("#EF4444")
    story.append(Paragraph(f"✅  DATA WIPE VERIFIED — {status}", ParagraphStyle("badge2",
        fontName="Helvetica-Bold", fontSize=16, textColor=badge_color, alignment=1, spaceAfter=4)))
    story.append(HRFlowable(width="100%", thickness=1, color=CYAN, spaceAfter=6))

    # ── CERT ID + QR ─────────────────────────────────────────────────────────
    qr_img_rl = RLImage(qr_path, width=28*mm, height=28*mm)
    id_block = [
        [Paragraph("CERTIFICATE ID", styles["h2"]),     ""],
        [Paragraph(cert["certificate_id"], ParagraphStyle("certid", fontName="Courier-Bold", fontSize=8, textColor=CYAN, leading=11)), qr_img_rl],
        [Paragraph(f"Issued: {cert['issued_at'][:19].replace('T',' ')} UTC", styles["body"]), ""],
        [Paragraph(f"Issued By: {cert['issued_by']}", styles["body"]), ""],
    ]
    id_table = Table(id_block, colWidths=[W*0.72, W*0.28])
    id_table.setStyle(TableStyle([
        ("BACKGROUND",  (0,0), (-1,-1), MID),
        ("TOPPADDING",  (0,0), (-1,-1), 5),
        ("BOTTOMPADDING",(0,0),(-1,-1), 5),
        ("LEFTPADDING", (0,0), (-1,-1), 10),
        ("RIGHTPADDING",(0,0), (-1,-1), 8),
        ("VALIGN",      (1,0), (1,-1),  "MIDDLE"),
        ("ROWSPAN",     (1,1), (1,2)),
        ("SPAN",        (1,1), (1,3)),
        ("LINEBELOW",   (0,-1),(-1,-1), 1, CYAN),
    ]))
    story.append(id_table)
    story.append(Spacer(1, 4*mm))

    # ── DEVICE INFO ──────────────────────────────────────────────────────────
    story.append(Paragraph("DEVICE INFORMATION", styles["h2"]))
    dev = cert["device"]
    dev_rows = [
        [Paragraph("Label",      styles["body"]), Paragraph(dev["label"],      styles["body"])],
        [Paragraph("Type",       styles["body"]), Paragraph(dev["type"],       styles["body"])],
        [Paragraph("Size",       styles["body"]), Paragraph(f"{dev['size_mb']} MB ({dev['size_mb']/1024:.2f} GB)", styles["body"])],
        [Paragraph("Filesystem", styles["body"]), Paragraph(dev["filesystem"],  styles["body"])],
    ]
    dev_table = Table(dev_rows, colWidths=[W*0.3, W*0.7])
    dev_table.setStyle(TableStyle([
        ("BACKGROUND",  (0,0), (0,-1), NAVY),
        ("BACKGROUND",  (1,0), (1,-1), MID),
        ("FONTNAME",    (0,0), (0,-1), "Helvetica-Bold"),
        ("TEXTCOLOR",   (0,0), (0,-1), CYAN),
        ("TOPPADDING",  (0,0), (-1,-1), 4),
        ("BOTTOMPADDING",(0,0),(-1,-1), 4),
        ("LEFTPADDING", (0,0), (-1,-1), 8),
        ("GRID",        (0,0), (-1,-1), 0.5, colors.HexColor("#1E3A5F")),
    ]))
    story.append(dev_table)
    story.append(Spacer(1, 4*mm))

    # ── WIPE RESULTS ─────────────────────────────────────────────────────────
    story.append(Paragraph("WIPE RESULTS", styles["h2"]))
    wr = cert["wipe_result"]
    wipe_rows = [
        ["Standard",           cert["standard"]],
        ["Method",             cert["wipe_method"]],
        ["Total Passes",       str(wr["total_passes"])],
        ["Entropy Score",      f"{wr['entropy_score']} / 8.0 bits"],
        ["Data Recovery Risk", wr["data_recovery_risk"]],
        ["Start Time",         wr["start_time"][:19].replace("T", " ") + " UTC"],
        ["End Time",           wr["end_time"][:19].replace("T", " ") + " UTC"],
        ["Verification",       wr["status"]],
    ]
    wipe_table = Table(
        [[Paragraph(r[0], styles["body"]), Paragraph(r[1], styles["body"])] for r in wipe_rows],
        colWidths=[W*0.35, W*0.65]
    )
    wipe_table.setStyle(TableStyle([
        ("BACKGROUND",  (0,0), (0,-1), NAVY),
        ("BACKGROUND",  (1,0), (1,-1), MID),
        ("FONTNAME",    (0,0), (0,-1), "Helvetica-Bold"),
        ("TEXTCOLOR",   (0,0), (0,-1), CYAN),
        ("TOPPADDING",  (0,0), (-1,-1), 4),
        ("BOTTOMPADDING",(0,0),(-1,-1), 4),
        ("LEFTPADDING", (0,0), (-1,-1), 8),
        ("GRID",        (0,0), (-1,-1), 0.5, colors.HexColor("#1E3A5F")),
        ("TEXTCOLOR",   (1,-1),(1,-1), GREEN),
        ("FONTNAME",    (1,-1),(1,-1), "Helvetica-Bold"),
    ]))
    story.append(wipe_table)
    story.append(Spacer(1, 4*mm))

    # ── PASS HASHES ──────────────────────────────────────────────────────────
    story.append(Paragraph("PASS-LEVEL SHA-256 VERIFICATION HASHES", styles["h2"]))
    for ph in wr.get("pass_hashes", []):
        story.append(Paragraph(
            f"Pass {ph['pass']} [{ph['pattern']}]:  {ph['sha256']}",
            styles["mono"]
        ))
    story.append(Spacer(1, 4*mm))

    # ── DIGITAL SIGNATURE ────────────────────────────────────────────────────
    story.append(Paragraph("DIGITAL SIGNATURE (RSA-2048 / SHA-256 / PSS)", styles["h2"]))
    sig_short = cert["digital_signature"][:80] + "..." + cert["digital_signature"][-40:]
    story.append(Paragraph(f"SHA-256 Hash: {cert['sha256_hash']}", styles["mono"]))
    story.append(Paragraph(f"Signature:    {sig_short}", styles["mono"]))
    story.append(Spacer(1, 3*mm))

    # ── FOOTER ───────────────────────────────────────────────────────────────
    story.append(HRFlowable(width="100%", thickness=1, color=CYAN, spaceAfter=4))
    story.append(Paragraph(
        "This certificate is digitally signed and tamper-proof. Scan QR code to verify. "
        "Generated by SecureWipe Pro — Team TechnoGreen, BMIT Solapur.",
        styles["center"]
    ))
    story.append(Paragraph(
        "Compliant with NIST SP 800-88 | DoD 5220.22-M | India IT Act 2000 Section 43A",
        ParagraphStyle("footer2", fontName="Helvetica-Bold", fontSize=8, textColor=CYAN, alignment=1)
    ))

    doc.build(story)
