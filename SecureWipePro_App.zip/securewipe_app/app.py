"""
SecureWipe Pro - Main Flask Application
Team TechnoGreen | BMIT Solapur
"""
import os, json, time, threading, uuid
from flask import Flask, render_template, jsonify, request, send_file, Response, stream_with_context
from wipe_engine import get_drives, simulate_wipe, METHODS
from cert_generator import generate_certificate

app = Flask(__name__)
app.secret_key = "securewipe_technogreen_2026"

CERT_DIR  = os.path.join(os.path.dirname(__file__), "certs")
WIPE_DIR  = os.path.join(os.path.dirname(__file__), "wipe_targets")
os.makedirs(CERT_DIR, exist_ok=True)
os.makedirs(WIPE_DIR, exist_ok=True)

# In-memory wipe session state
_sessions = {}   # session_id -> { progress, log, cert }


# ── ROUTES ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/drives")
def api_drives():
    drives = get_drives()
    # Add a safe demo drive always
    drives.insert(0, {
        "device": "DEMO",
        "mountpoint": "Demo / Test File",
        "fstype": "DEMO",
        "total_gb": 0.1,
        "used_gb": 0.05,
        "free_gb": 0.05,
        "percent": 50,
        "drive_type": "🔵 Demo Mode (Safe)",
    })
    return jsonify(drives)


@app.route("/api/methods")
def api_methods():
    return jsonify(METHODS)


@app.route("/api/wipe/start", methods=["POST"])
def api_wipe_start():
    data      = request.json
    method    = data.get("method", "dod3")
    drive     = data.get("drive", {})
    size_mb   = int(data.get("size_mb", 5))   # default 5 MB for demo
    session_id = str(uuid.uuid4())

    _sessions[session_id] = {
        "progress": {"percent": 0, "pass_label": "Initializing...", "pass": 0, "total_passes": 1},
        "done":     False,
        "log":      None,
        "cert":     None,
        "error":    None,
        "drive":    drive,
        "method":   method,
    }

    def do_wipe():
        target = os.path.join(WIPE_DIR, f"wipe_{session_id[:8]}.bin")
        try:
            def cb(prog):
                _sessions[session_id]["progress"] = prog

            log = simulate_wipe(target, method, size_mb, callback=cb)
            cert = generate_certificate(log, drive)
            _sessions[session_id]["log"]  = log
            _sessions[session_id]["cert"] = cert
            _sessions[session_id]["done"] = True
        except Exception as e:
            _sessions[session_id]["error"] = str(e)
            _sessions[session_id]["done"]  = True
        finally:
            if os.path.exists(target):
                os.remove(target)

    threading.Thread(target=do_wipe, daemon=True).start()
    return jsonify({"session_id": session_id})


@app.route("/api/wipe/progress/<session_id>")
def api_wipe_progress(session_id):
    def generate():
        while True:
            sess = _sessions.get(session_id)
            if not sess:
                yield f"data: {json.dumps({'error': 'Session not found'})}\n\n"
                break
            payload = {**sess["progress"], "done": sess["done"], "error": sess["error"]}
            yield f"data: {json.dumps(payload)}\n\n"
            if sess["done"]:
                break
            time.sleep(0.25)
    return Response(stream_with_context(generate()), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@app.route("/api/wipe/result/<session_id>")
def api_wipe_result(session_id):
    sess = _sessions.get(session_id, {})
    if not sess.get("done"):
        return jsonify({"error": "Not done yet"}), 400
    cert = sess.get("cert", {})
    return jsonify({
        "cert_id":  cert.get("cert_id", ""),
        "cert_data": cert.get("cert_data", {}),
        "wipe_log": sess.get("log", {}),
    })


@app.route("/api/cert/download/pdf/<session_id>")
def download_pdf(session_id):
    sess = _sessions.get(session_id, {})
    cert = sess.get("cert", {})
    if not cert:
        return "Not found", 404
    return send_file(cert["pdf_path"], as_attachment=True,
                     download_name=f"WipeCert_{cert['cert_id'][:8]}.pdf")


@app.route("/api/cert/download/json/<session_id>")
def download_json(session_id):
    sess = _sessions.get(session_id, {})
    cert = sess.get("cert", {})
    if not cert:
        return "Not found", 404
    return send_file(cert["json_path"], as_attachment=True,
                     download_name=f"WipeCert_{cert['cert_id'][:8]}.json")


@app.route("/api/cert/qr/<session_id>")
def get_qr(session_id):
    sess = _sessions.get(session_id, {})
    cert = sess.get("cert", {})
    if not cert:
        return "Not found", 404
    return send_file(cert["qr_path"], mimetype="image/png")


@app.route("/api/verify", methods=["POST"])
def api_verify():
    """Verify a JSON certificate's digital signature."""
    import base64, hashlib, json as J
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import padding
    from cryptography.hazmat.backends import default_backend

    f = request.files.get("cert_file")
    if not f:
        return jsonify({"valid": False, "error": "No file uploaded"})
    try:
        data = J.loads(f.read())
        sig         = base64.b64decode(data.pop("digital_signature"))
        pub_pem     = data.pop("public_key_pem").encode()
        stored_hash = data.pop("sha256_hash")

        cert_bytes = J.dumps(data, sort_keys=True).encode()
        computed   = hashlib.sha256(cert_bytes).hexdigest()

        pub_key = serialization.load_pem_public_key(pub_pem, backend=default_backend())
        pub_key.verify(sig, cert_bytes,
                       padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
                       hashes.SHA256())

        return jsonify({
            "valid":     True,
            "cert_id":   data.get("certificate_id", ""),
            "issued_at": data.get("issued_at", ""),
            "hash_match": computed == stored_hash,
            "device":    data.get("device", {}),
            "result":    data.get("wipe_result", {}),
        })
    except Exception as e:
        return jsonify({"valid": False, "error": str(e)})


if __name__ == "__main__":
    print("\n" + "="*60)
    print("  🔐 SecureWipe Pro — Starting...")
    print("  🌐 Open: http://localhost:5000")
    print("  👥 Team TechnoGreen | BMIT Solapur")
    print("="*60 + "\n")
    app.run(debug=True, port=5000, threaded=True)
